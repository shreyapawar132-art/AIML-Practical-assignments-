AIML PRACTICALS - VS CODE RUNNABLE PYTHON FILES
=================================================

Assignments:
1. Association Between Dependent and Independent Variables
2. K-Means Clustering Using Unsupervised Learning
3. Dimensionality Reduction Using PCA
4. Naive Bayes Classification
5. KNN Classification
6. Linear Regression
7. SVM Algorithm for Regression (SVR)
8. Regularization to Avoid Overfitting
9. Object / Motion Detection from CCTV Footage
10. Fake News Detection from Multimodal Data

SETUP IN VS CODE
----------------
Open this folder in VS Code.

1. Open Terminal -> New Terminal.
2. Install the required libraries:
   pip install -r requirements.txt

3. Run any assignment:
   python assignment_01.py
   python assignment_02.py
   ...
   python assignment_10.py

Notes:
- Assignments 1, 2, 3, 5, 6 and 7 use scikit-learn built-in datasets.
- Assignment 4 contains the small labeled SMS sample used in the practical.
- Assignment 8 creates its nonlinear sample data inside the program.
- Assignment 9 automatically creates cctv_input.mp4 if it is not present.
- Assignment 10 automatically creates a small paired image dataset so it can run without downloading images.

For Assignment 9, press ESC to stop the CCTV preview window.
